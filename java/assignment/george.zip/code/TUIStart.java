/**
 * class: TUIStart
 * purpose: Initialize the TUI
 */

public class TUIStart {

  public static void main (String[] args) {
    new TUI();
  }

}
